package com.cg.employee.service;

public interface IEmployeeService
{
	public void searchID();
	
	public void searchFName();
	
	public void searchLName();
	
	public void searchDepartment();
	
	public void searchGrade();
	
	public void searchMaritalStatus();
}
