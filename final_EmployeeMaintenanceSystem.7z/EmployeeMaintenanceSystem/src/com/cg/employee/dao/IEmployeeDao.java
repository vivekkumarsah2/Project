package com.cg.employee.dao;

public interface IEmployeeDao
{
	public void EmpCon();
	
	public void search(String field, String pattern);
}
