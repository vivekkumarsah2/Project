package com.cg.service;

public interface IAuthenticationService 
{
	public boolean Authenticate(String uid, String uname, String upassword);
}
