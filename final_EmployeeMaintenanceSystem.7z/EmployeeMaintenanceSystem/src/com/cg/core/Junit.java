package com.cg.core;

import static org.junit.Assert.assertEquals;
import java.time.LocalDate;
import org.junit.Test;
import com.cg.admin.dao.AdminDao;
import com.cg.employee.bean.Employee;

public class Junit {

	@Test
	public void testepdepDetails()
	{
		Employee ep = new Employee();
		ep.setEId("100001");			//change this value every time you test (as EId is PK)
		ep.setEFName("Hey");
		ep.setELName("Person");
		ep.setDOB(LocalDate.of(1997, 05, 11));
		ep.setDOJ(LocalDate.of(2018, 10, 15));
		ep.setDeptId(45);
		ep.setEGrade("M3");
		ep.setEDesignation("SA");
		ep.setEBasic((long)450000);
		ep.setEGender("Male");
		ep.setEMaritalStatus("Single");
		ep.setEAddress("XYZ");
		ep.setEContact("1234567890");
				
		AdminDao test = new AdminDao();
		assertEquals(true, test.add(ep));
	}
	
	
}
